<!-- Footer opened -->
<footer class="bg-white p-4">
    <div class="row">
        <div class="col-md-12">
            <div class="text-center">
                <p class="mb-0"> &copy; Copyright <span id="copyright">
                        <script>
                            document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
                        </script>
                    </span>. <a href="https://portfolio.kareemsoft.online/"> Kareem Shaban </a> All Rights Reserved. </p>
            </div>
        </div>

    </div>
</footer>
<!-- Footer closed -->
