<head>
    <meta charset="utf-8">
    <title>المصاعد الدولية</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('frontend/img/logo_1.png') }}" />

    @php
        $metaData = App\Models\MetaData::pluck('value', 'key')->toArray(); // Populate the $metaData property
    @endphp

    <meta content="{{ $metaData['description'] }}" name="description">
    {{-- <meta content="{{ $metaData['keywords'] }}" name="keywords"> --}}
    @yield('keywords')

    <!-- Add a canonical tag to specify the preferred version of the page -->
    <link rel="canonical" href="{{ $metaData['canonical_link'] }}">

    <!-- Add Open Graph metadata for social media sharing -->
    <meta property="og:title" content="{{ $metaData['og:title'] }}">
    <meta property="og:description" content="{{ $metaData['og:description'] }}">
    <meta property="og:url" content="{{ $metaData['og:url'] }}">
    <meta property="og:type" content="{{ $metaData['og:type'] }}">
    <meta property="og:site_name" content="{{ $metaData['og:site_name'] }}">
    <meta property="article:publisher" content="{{ $metaData['article:publisher'] }}">
    <meta property="og:updated_time" content="{{ $metaData['og:updated_time'] }}">
    <meta property="og:image" content="{{ $metaData['og:image'] }}">
    <meta property="og:image:secure_url" content="{{ $metaData['og:image:secure_url'] }}">
    <meta property="og:image:width" content="{{ $metaData['og:image:width'] }}">
    <meta property="og:image:height" content="{{ $metaData['og:image:height'] }}">
    <meta property="og:image:alt" content="{{ $metaData['og:image:alt'] }}">
    <meta property="og:image:type" content="{{ $metaData['og:image:type'] }}">
    <meta property="article:published_time" content="{{ $metaData['article:published_time'] }}">
    <meta property="article:modified_time" content="{{ $metaData['article:modified_time'] }}">

    <!-- Add Twitter Card metadata for Twitter sharing -->
    <meta name="twitter:card" content="{{ $metaData['twitter:card'] }}">
    <meta name="twitter:title" content="{{ $metaData['twitter:title'] }}">
    <meta name="twitter:description" content="{{ $metaData['twitter:description'] }}">
    <meta name="twitter:image" content="{{ $metaData['twitter:image'] }}">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@400;600;800&family=Roboto:wght@400;500;700&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/4.6.3/css/ionicons.min.css">

    <!-- Vendor CSS Files -->
    {{-- <link href="{{ asset('frontend/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet"> --}}
    <link href="{{ asset('frontend/vendor/icofont/icofont.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/vendor/venobox/venobox.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/vendor/owl.carousel/assets/owl.carousel.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/vendor/aos/aos.css') }}" rel="stylesheet">


    <!-- Libraries Stylesheet -->
    <link href="{{ asset('frontend/lib/animate/animate.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/lib/owlcarousel/assets/owl.carousel.min.css') }}" rel="stylesheet">

    <link href="{{ asset('frontend/css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->

    <!-- Template Stylesheet -->
    {{-- @if (App::getLocale() == 'en')
        <link href="{{ asset('frontend/css/style.css') }}" rel="stylesheet">
    @else --}}
    <link href="{{ asset('frontend/css/rtl.css') }}" rel="stylesheet">
    {{-- @endif --}}

    <link href="{{ asset('frontend/css/custom.css') }}" rel="stylesheet">


    {{-- <link href="{{ asset('frontend/css/wp.css') }}" rel="stylesheet"> --}}


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    @stack('style')

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>

    {{-- <style>
        .chaty-widget {
            position: fixed;
            z-index: 9999;
        }

        .chaty-widget.chaty-widget-show .chaty-widget-is {
            pointer-events: auto;
            overflow: visible;
            opacity: 1;
            visibility: visible;
        }

        .chaty-widget .chaty-widget-is {
            display: flex;
            z-index: 1111;
            flex-wrap: wrap;
            overflow: hidden;
            height: 0;
            position: absolute;
            pointer-events: none;
            left: 0;
            right: auto;
            bottom: 65px;
            opacity: 0;
        }
    </style> --}}
</head>
