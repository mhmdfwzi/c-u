<section class="news-section page-header">
    <div class="news-container">
        <div class="newsletter ">
            <section class="name">
                <p> جريدة المصاعد الدولية</p>
            </section>

            <section class="info">
                {{-- <p>DAILY NEWS</p>
                <p>35¢</p> --}}
            </section>

            <section class="title">
                <h1>
                    <span>المصاعد الدولية</span>
                    {{-- <span>Simpsons scam</span>
                    <span>Springfield</span> --}}
                </h1>
            </section>

            <section class="content">
                <div class="row">
                    <div class="col-md-7">
                        <article class="left-side">
                            <h2>
                                <span>Angry Mob</span>
                                <span>Mulls Options</span>
                            </h2>
                            <div>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has
                                    been
                                    the industry's standard dummy text ever since the 1500s, when an unknown printer
                                    took a
                                    galley
                                    of type and scrambled it to make a type specimen book.</p>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has
                                    been
                                    the industry's standard dummy text ever since the 1500s, when an unknown printer
                                    took a
                                    galley
                                    of type and scrambled it to make a type specimen book.</p>
                            </div>
                        </article>
                    </div>
                    <div class="col-md-5">
                        <article class="right-side wow fadeInUp" data-wow-delay="0.1s">
                            {{-- <img src="https://i.ibb.co/R6vng5P/family-simpson.jpg" alt="Simpsons family photo"> --}}
                            <img src="{{ asset('frontend/img/logo.png') }}" alt="">
                            {{-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                                                      the
                                                      industry's</p> --}}
                        </article>
                    </div>
                </div>


            </section>
        </div>
    </div>
</section>
