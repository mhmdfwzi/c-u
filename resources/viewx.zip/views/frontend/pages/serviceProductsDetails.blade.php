@extends('frontend.layouts.master')
@php
    $metaData = App\Models\MetaData::pluck('value', 'key')->toArray(); // Populate the $metaData property
@endphp
@section('keywords')
    <meta content="{{ $metaData['keywords'] }}" name="keywords">
@endsection

@section('content')
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-4">{{ $serviceProduct->title }}</h1>

        </div>
    </div>
    <!-- Page Header End -->


    <div class="container-xxl py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7" >
                    <div   style="margin: auto; display: table; ">
                    <img src="{{ $serviceProduct->image_urll }}" style="max-height:400px; max-width:700px" alt="">
                </div>
                    <div class="d-flex justify-content-center my-4">
                        <a href="{{ route('createOrder', $serviceProduct->id) }}" class="btn btn-info text-white ">
                            @if ($serviceProduct->type == 'product')
                                طلب
                                المنتج
                            @else
                                طلب
                                الخدمة
                            @endif
                        </a>
                    </div>
                    {!! $serviceProduct->content !!}
                    <div class="sharethis-inline-share-buttons"></div>
                </div>
                <div class="col-lg-1 col-md-1">
                </div>

                <div class="col-lg-4 col-md-4 mt-4">


                    <h4>منتجات أخرى</h4>
                    @foreach ($popularServiceProduct as $popular)
                        <div class="d-flex mt-5" style="justify-content: flex-start; align-items:center">

                            <img src="{{ $popular->image_url }}" style="height: 50px; width:100px" alt="">
                            {{-- <a href="{{ route('serviceProductDetails', $popular->id) }}" style="color: black">
                                <span class="mx-4">{{ $popular->title }}</span>
                            </a> --}}

                            <div style="display: block">
                                <a href="{{ route('serviceProductDetails', $popular->id) }}" style="color: black">
                                    <span class="mx-4" style="font-weight: bold">{{ $popular->title }}</span>
                                </a>
                                <p class="mx-4 mb-0">

                                    {!! \Illuminate\Support\Str::words(strip_tags($popular->content), 10, '...') !!}

                                </p>
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script type="text/javascript"
        src="https://platform-api.sharethis.com/js/sharethis.js#property=6566f0433bcaed00121fca65&product=inline-share-buttons&source=platform"
        async="async"></script>
@endpush
