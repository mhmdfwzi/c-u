@extends('frontend.layouts.master')

@php
    $metaData = App\Models\MetaData::pluck('value', 'key')->toArray(); // Populate the $metaData property
@endphp
@section('keywords')
    <meta content="{{ $metaData['keywords'] }}" name="keywords">
@endsection

@push('style')
    <style>
        .slick-slide {
            margin: 0 20px;
        }

        .slick-slide img {
            width: 100%;
        }

        .slick-slider {
            position: relative;
            display: block;
            box-sizing: border-box;
        }

        .slick-list {
            position: relative;
            display: block;
            overflow: hidden;
            margin: 0;
            padding: 0;
        }

        .slick-track {
            position: relative;
            top: 0;
            left: 0;
            display: block
        }

        .slick-slide {
            display: none;
            float: left;
            height: 100%;
            min-height: 1px;
        }

        .slick-slide img {
            display: block;
            border-radius: 50%;
        }

        .slick-initialized .slick-slide {
            display: block;
        }

        .copy {
            padding-top: 250px;
        }

        :root {
            --light: #F2F7F4;
            --red: #F04F78;
            --green: #0EAF9B;
            --on: #30E1B9;
        }

        /* GENERAL */
        /* body {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                width: 100%;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                height: 100vh;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                display: flex;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                justify-content: center;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                align-items: center;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                background-color: var(--light);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            } */

        svg {
            width: 350px;
            height: 350px;
            position: absolute;
            top: 0;
            left: 14%
        }

        /* ANIMATIONS */
        .left-door {
            animation: left-door 1s ease 5s forwards;
        }

        @keyframes left-door {
            0% {
                transform: translateX(0);
            }

            100% {
                transform: translateX(-14px);
            }
        }

        .right-door {
            animation: right-door 1s ease 5s forwards;
        }

        @keyframes right-door {
            0% {
                transform: translateX(0);
            }

            100% {
                transform: translateX(14px);
            }
        }

        .floor-5 {
            animation: light-to-red 1s ease 0s forwards;
        }

        .floor-4 {
            animation: light-to-red 1s ease 1s forwards;
        }

        .floor-3 {
            animation: light-to-red 1s ease 2s forwards;
        }

        .floor-2 {
            animation: light-to-red 1s ease 3s forwards;
        }

        .floor-1 {
            animation: light-to-green 1s ease 4s forwards;
        }

        @keyframes light-to-red {
            0% {
                fill: var(--green);
            }

            80% {
                fill: var(--green);
            }

            100% {
                fill: var(--red);
            }
        }

        @keyframes light-to-green {
            0% {
                fill: var(--green);
            }

            100% {
                fill: var(--green);
            }
        }

        #control-up {
            cursor: pointer;
        }

        .arrow-up {
            fill: var(--on);
        }

        .elevator-container {

            position: relative;
            width: 100%;
            /* Adjust as needed */
            height: 50vh;
            /* Adjust as needed */
        }

        #welcome-message {
            position: absolute;
            top: 50%;
            /* left: 65%; */
            left: 260px;
            padding: 0px;
            transform: translate(-50%, -50%);
            background-color: transparent;
            color: white;
            opacity: 0;
            transition: opacity 1s ease;
            width: 60px;
            text-align: center;
            font-weight: bold;
        }

        #welcome-message h4 {
            font-size: 18px
        }

        #welcome-message.show {
            opacity: 1;
            /* Fade in when the 'show' class is added */
        }

        .click-here {
            text-align: center;
            position: absolute;
            top: 160px;
            left: 363px;
            width: 50px;
            animation: whatsapp-button-animation 1s infinite
        }

        .shape-section {
            height: 100%;
        }

        @media (max-width: 768px) {
            svg {
                width: 250px;
                height: 250px;
            }

            #welcome-message {
                position: absolute;
                top: 38%;
                /* left: 65%; */
                left: 185px;
                padding: 0px;
                transform: translate(-50%, -50%);
                background-color: transparent;
                color: white;
                opacity: 0;
                transition: opacity 1s ease;
                width: 60px;
                text-align: center;
                font-weight: bold;
            }

            #welcome-message h4 {
                font-size: 15px
            }

            .click-here {
                font-size: 14px;
                text-align: center;
                position: absolute;
                top: 110px;
                left: 250px;
                width: 50px;
                animation: whatsapp-button-animation 1s infinite;
            }
        }
    </style>
    <style>
        .news-section {
            display: flex;
            /* height: 100vh; */
            justify-content: center;
            align-items: center;
            background-color: dimgray;
            padding: 40px 0px;
        }

        .news-container {
            animation: scale-up 2.5s linear;
        }

        .newsletter {
            /* width: 800px; */
            width: 80%;
            margin: auto;
            background-color: whitesmoke;
            padding: 5px;
            border: 1px solid black;
            /* transform: rotate(-5deg); */
            animation: rotate 0.5s linear 5;
            position: relative;
        }

        .newsletter::before {
            content: '';
            width: 8px;
            height: 98%;
            position: absolute;
            left: -10px;
            top: 1%;
            background-color: whitesmoke;
            border: 1px solid black;
        }

        .newsletter::after {
            content: '';
            width: 8px;
            height: 96%;
            position: absolute;
            left: -19px;
            top: 2%;
            background-color: whitesmoke;
            border: 1px solid black;
        }

        .name {
            display: flex;
            justify-content: center;
            padding-bottom: 20px;
            font-size: 60px;
        }

        .info {
            display: flex;
            justify-content: space-between;
            border-top: 1px solid black;
            border-bottom: 1px solid black;
            padding: 10px 5px;
        }

        .title h1 {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 10px;
            font-size: 65px;
        }

        .content {
            display: flex;
        }

        .left-side {
            display: flex;
            flex-direction: column;
        }

        .left-side h2 {
            display: flex;
            flex-direction: column;
            border-top: 1px solid black;
            border-bottom: 1px solid black;
            padding: 10px 5px;
        }

        .left-side div {
            /* display: flex; */
        }

        .left-side div p {
            padding: 5px;
        }

        .right-side {
            padding: 0 10px;
            font-size: x-small;
        }

        @keyframes rotate {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(-360deg);
            }
        }

        @keyframes scale-up {
            0% {
                transform: scale(1%);
            }

            100% {
                transform: scale(100%);
            }
        }

        @media (max-width: 768px) {
            .news-section {
                display: none
            }
        }
    </style>
@endpush

@section('content')
    <!-- Gallery Start -->
    <div class="container-fluid p-0">
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">

                @foreach ($gallery as $index => $item)
                    <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                        <img class="w-100" style="height: 650px" src="{{ $item->image_url }}" alt="Image">
                        <div class="carousel-caption">
                            <div class="container-fluid">
                                <div class="row justify-content-center">
                                    <div class="col-lg-12" style="margin-top: 275px; background: rgb(46 54 55 / 50%)">
                                        <h5 class="display-4 text-white mb-4 animated slideInDown" style="font-size: 35px">
                                            {{ $item->title }}</h5>
                                        <p class="fs-5 text-body mb-4 pb-2 mx-sm-5 animated slideInDown">
                                            {{ $item->sub_title }}</p>
                                        {{-- <a href="" class="btn btn-primary py-3 px-5 animated slideInDown">Explore
                                        More</a> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach

            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!-- Gallery End -->


    {{-- about us section --}}
    @include('frontend.pages.HomeParts.aboutSection')

    {{-- Our Services --}}
    @include('frontend.pages.HomeParts.ourServicesSection')


    {{-- our products --}}
    @include('frontend.pages.HomeParts.ourProductsSection')



    <div class="container-xxl shape-section pt-5">
        <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <h1 style="font-size: 28px" class="mb-5"> لماذا تختار مؤسسة المصاعد الدولية ؟ </h1>
        </div>
        <div class="row align-items-center ">
            <div class="col-lg-7 col-md-7 wow fadeInUp" data-wow-delay="0.1s">
                {{-- <h1 class="mb-5" style="font-size: 28px"> بعض الأسباب التي تجعل الأشخاص يختاروننا ! </h1> --}}
                <p>
                    لأننا نفهم احتياجات السوق ونعمل على إيجاد أفضل الحلول ضمن معايير الجودة والسلامة بأسعار تنافسية، ومتابعة
                    أحدث التقنيات العالمية. هذه بعض من نقاط القوة في صناعة وتركيب المصاعد لدينا، والتي منها: -
                </p>
                <ul>
                    <li>
                        - المصاعد الدولية هي مؤسسة مصاعد رائدة في المملكة ومقرها مدينة أبها
                    </li>
                    <li>
                        - نقدم خدمات المصاعد المتكاملة فائقة الجودة وموثوقة لأكثر من 15 عام
                    </li>
                    <li>- نقدم أفضل خدمات الصيانة والتركيب إلى التشغيل النهائي وما بعد البيع لجميع أنواع المصاعد.</li>
                    <li>- نمتلك خبرة واسعة وتنوع في المنتجات بما يتناسب مع احتياجات عملائنا في هذا المجال</li>
                    <li>- لدينا مهندسين وفنيين مدربين علي اعلي مستوي لتزويدك بالأمان والموثوقية</li>
                    <li>- قطع الغيار ذات الطلب النادر، يتم توفيرها خلال فترة 14 يوم.</li>
                    <li>- دعم فني لتركيب وخدمة المنتجات من خلال مركز الاتصال الخاص بنا على مدار 24 ساعة / 7 أيام.</li>
                </ul>

            </div>


            <div class="col-lg-5 col-md-5 wow fadeInUp" data-wow-delay="0.1s" style="position: relative">
                <div class="elevator-container">

                    <svg width="94" height="94" viewBox="0 0 64 64" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g id="elevator">
                            <g id="inside-elevator">
                                <path id="inside-elevator_2"
                                    d="M18 20.5H46C46.8284 20.5 47.5 21.1716 47.5 22V58.5H16.5V22C16.5 21.1716 17.1716 20.5 18 20.5Z"
                                    fill="#7D929B" stroke="#3E3546" />
                                <path id="Vector 9" d="M20.5 52.5L16.5 58.5H47.5L43.5 52.5H20.5Z" fill="#625565" />
                                <rect id="Rectangle 39" x="23.5" y="23.5" width="17" height="17" rx="1.5"
                                    fill="#8FD3FF" stroke="#3E3546" />
                                <!-- <path id="Vector 8" d="M29 35L35 29M32 36L36 32M28 32L32 28" stroke="#F4EDF5" stroke-linecap="round"/> -->
                                <path id="Vector 7" d="M16.5 49.5L20.5 43.5H43.5L47.5 49.5" stroke="#3E3546" />
                                <path id="Vector 6"
                                    d="M20.5 52.5L16.5 58.5H47.5L43.5 52.5M20.5 52.5H43.5M20.5 52.5V20.5M43.5 52.5V20.5"
                                    stroke="#3E3546" />
                            </g>
                            <path id="left-door" d="M19 20.5H31.5V58.5H16.5V23C16.5 21.6193 17.6193 20.5 19 20.5Z"
                                fill="#9BABB2" stroke="#3E3546" />
                            <path id="right-door" d="M32.5 20.5H45C46.3807 20.5 47.5 21.6193 47.5 23V58.5H32.5V20.5Z"
                                fill="#9BABB2" stroke="#3E3546" />
                            <path id="elevator-bg" fill-rule="evenodd" clip-rule="evenodd"
                                d="M64 0H0V64H64V0ZM16 11C13.7909 11 12 12.7909 12 15V59H52V15C52 12.7909 50.2091 11 48 11H16Z"
                                fill="#F2F7F4" />
                            <g id="elevator-front">
                                <mask id="path-10-inside-1_102_4" fill="white">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M16 11C13.7909 11 12 12.7909 12 15V59H17V23C17 21.8954 17.8954 21 19 21H45C46.1046 21 47 21.8954 47 23V59H52V15C52 12.7909 50.2091 11 48 11H16Z" />
                                </mask>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M16 11C13.7909 11 12 12.7909 12 15V59H17V23C17 21.8954 17.8954 21 19 21H45C46.1046 21 47 21.8954 47 23V59H52V15C52 12.7909 50.2091 11 48 11H16Z"
                                    fill="#9BABB2" />
                                <path
                                    d="M12 59H11V60H12V59ZM17 59V60H18V59H17ZM47 59H46V60H47V59ZM52 59V60H53V59H52ZM13 15C13 13.3431 14.3431 12 16 12V10C13.2386 10 11 12.2386 11 15H13ZM13 59V15H11V59H13ZM17 58H12V60H17V58ZM18 59V23H16V59H18ZM18 23C18 22.4477 18.4477 22 19 22V20C17.3431 20 16 21.3431 16 23H18ZM19 22H45V20H19V22ZM45 22C45.5523 22 46 22.4477 46 23H48C48 21.3431 46.6569 20 45 20V22ZM46 23V59H48V23H46ZM52 58H47V60H52V58ZM51 15V59H53V15H51ZM48 12C49.6569 12 51 13.3431 51 15H53C53 12.2386 50.7614 10 48 10V12ZM16 12H48V10H16V12Z"
                                    fill="#3E3546" mask="url(#path-10-inside-1_102_4)" />
                            </g>
                            <line id="floor" x1="4.5" y1="58.5" x2="59.5" y2="58.5"
                                stroke="#3E3546" stroke-linecap="round" />
                            <circle id="floor-1" cx="18" cy="16" r="1.5" fill="#F04F78"
                                stroke="#3E3546" />
                            <circle id="floor-2" cx="25" cy="16" r="1.5" fill="#F04F78"
                                stroke="#3E3546" />
                            <circle id="floor-3" cx="32" cy="16" r="1.5" fill="#F04F78"
                                stroke="#3E3546" />
                            <circle id="floor-4" cx="39" cy="16" r="1.5" fill="#F04F78"
                                stroke="#3E3546" />
                            <circle id="floor-5" cx="46" cy="16" r="1.5" fill="#0EAF9B"
                                stroke="#3E3546" />
                            <g id="control-up">
                                <rect id="base" x="54.5" y="40.5" width="7" height="6" rx="1.5"
                                    fill="#9BABB2" stroke="#3E3546" />
                                {{-- <path id="arrow-up" d="M56 44.5L57 42L58 44.5H56Z" fill="#3E3546" /> --}}
                                <path id="arrow-up" d="M56 44.5L58 42L60 44.5H56Z" fill="#3E3546" />

                            </g>
                            <g id="plant">
                                <g id="leaf">
                                    <g id="Rectangle 40">
                                        <mask id="path-20-inside-2_102_4" fill="white">
                                            <path
                                                d="M3.69056 34.4498C3.26247 31.025 5.93289 28 9.38434 28V28C12.8358 28 15.5062 31.025 15.0781 34.4498L12.8843 52H5.88434L3.69056 34.4498Z" />
                                        </mask>
                                        <path
                                            d="M3.69056 34.4498C3.26247 31.025 5.93289 28 9.38434 28V28C12.8358 28 15.5062 31.025 15.0781 34.4498L12.8843 52H5.88434L3.69056 34.4498Z"
                                            fill="#0EAF9B" stroke="#3E3546" stroke-width="2"
                                            mask="url(#path-20-inside-2_102_4)" />
                                    </g>
                                    <path id="Line 11"
                                        d="M9.38434 51.5V35M9.38434 32L9.38434 35M9.38434 35L11.8843 33M9.38434 35L6.88434 33M11.8843 36L9.38434 38L6.88434 36M11.8843 39L9.38434 41L6.88434 39M11.8843 42L9.38434 44L6.88434 42M11.3843 45.5L9.38434 47L7.38434 45.5M10.8843 49L9.38434 50L7.88434 49"
                                        stroke="#3E3546" stroke-linecap="round" />
                                </g>
                                <g id="potter">
                                    <g id="Rectangle 38">
                                        <mask id="path-22-inside-3_102_4" fill="white">
                                            <path
                                                d="M4.19497 52.2425C4.03719 51.6114 4.51454 51 5.16511 51H13.6036C14.2541 51 14.7315 51.6114 14.5737 52.2425L12.8843 59H5.88434L4.19497 52.2425Z" />
                                        </mask>
                                        <path
                                            d="M4.19497 52.2425C4.03719 51.6114 4.51454 51 5.16511 51H13.6036C14.2541 51 14.7315 51.6114 14.5737 52.2425L12.8843 59H5.88434L4.19497 52.2425Z"
                                            fill="#F68181" stroke="#3E3546" stroke-width="2"
                                            mask="url(#path-22-inside-3_102_4)" />
                                    </g>
                                    <path id="Vector 5" d="M5.38434 53.5H13.3843" stroke="#3E3546" />
                                </g>
                            </g>
                        </g>
                    </svg>

                    <div class="click-here">
                        <span>أضغط هنا</span>
                    </div>


                </div>
                <div id="welcome-message">
                    <h4>المصاعد الدولية</h4>
                </div>

            </div>
        </div>
    </div>




    {{-- our clients --}}
    @include('frontend.pages.HomeParts.ourClientsSection')
@endsection

@push('scripts')
    <script>
        $('.customer-logos').slick({
            slidesToShow: 6,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 1500,
            arrows: false,
            dots: false,
            pauseOnHover: false,
            responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 4
                    }
                },
                {
                    breakpoint: 520,
                    settings: {
                        slidesToShow: 3
                    }
                }
            ]
        });

        const leftDoor = document.getElementById('left-door');
        const rightDoor = document.getElementById('right-door');
        const floor1 = document.getElementById('floor-1');
        const floor2 = document.getElementById('floor-2');
        const floor3 = document.getElementById('floor-3');
        const floor4 = document.getElementById('floor-4');
        const floor5 = document.getElementById('floor-5');
        const controlUp = document.getElementById('control-up');
        const arrowUp = document.getElementById('arrow-up');
        const welcomeMessage = document.getElementById('welcome-message');


        // Elevator animation function
        function elevator() {
            leftDoor.classList.add('left-door');
            rightDoor.classList.add('right-door');
            floor1.classList.add('floor-1');
            floor2.classList.add('floor-2');
            floor3.classList.add('floor-3');
            floor4.classList.add('floor-4');
            floor5.classList.add('floor-5');
            arrowUp.classList.add('arrow-up');

            setTimeout(() => {
                welcomeMessage.classList.add('show');
            }, 6000); // Adjust the delay based on your animation duration
        }


        // Click to start the animation
        controlUp.addEventListener('click', elevator);
    </script>
@endpush
