@extends('frontend.layouts.master')
@php
    $metaData = App\Models\MetaData::pluck('value', 'key')->toArray(); // Populate the $metaData property
@endphp
@section('keywords')
    <meta content="{{ $metaData['keywords'] }}" name="keywords">
@endsection

@section('content')
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-4">{{ $blogNews->title }}</h1>

        </div>
    </div>
    <!-- Page Header End -->


    <div class="container-xxl py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7">
                    <div  class="image" style="margin: auto; display: table;">
                        <img src="{{ $blogNews->image_urll }}" style="max-height:400px; max-width:700px" alt="">
                    </div> 

                    {!! $blogNews->content !!}
                    <div class="sharethis-inline-share-buttons"></div>
                </div>
                <div class="col-lg-1 col-md-1">
                </div>

                <div class="col-lg-4 col-md-4 mt-4">


                    <h4>اخبار ومدونات أخرى</h4>
                    @foreach ($popularBlogNews as $popular)
                        <div class="d-flex mt-5" style="justify-content: flex-start; align-items:center">

                            <img src="{{ $popular->image_url }}" style="height: 50px; width:100px" alt="">
                            <a href="{{ route('blogNewsDetails', $popular->id) }}" style="color: black">
                                <span class="mx-4">{{ $popular->title }}</span>
                            </a>

                        </div>
                    @endforeach

                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script type="text/javascript"
        src="https://platform-api.sharethis.com/js/sharethis.js#property=6566f0433bcaed00121fca65&product=inline-share-buttons&source=platform"
        async="async"></script>
@endpush
