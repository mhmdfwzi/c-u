<?php $__env->startSection('seo_data'); ?>
    <?php echo $__env->make('frontend.layouts.default_seo_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-4">من نحن ؟</h1>

        </div>
    </div>
    <!-- Page Header End -->


    <div class="container-xxl py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4"></div>
                <div class="col-lg-8 col-md-8">
                    <ul>
                        <li>

                            أسست مؤسسة المصاعد الدولية نشاطها بالمملكة العربية السعودية منذ عام
                            1427هـ / 2007م؛ وطوال هذه المدة أصبح اسم ”المصاعد الدولية“ عالمة فارقه
                            لدى السوق السعودي الذي يهتم بالجودة العالية مقابل السعر المنافس والتنفيذ
                            السريع، واستطاعت أن ت لبي رغبة عمالئها عن طريق اختيار أجود الخامات في
                            العمل واستخدام أحدث وسائل التكنولوجيا لجميع أنواع المباني، والتنفيذ عن طريق
                            فنيين متخصصين على أعلى درجة من المهارة والسرعة وتحت إشراف مهندسين
                            على درجة عالية من التخصص والكفاءة في أعمال التركيب و الصيانة، في عالم
                            المصاعد الكهربائية وملحقاتها من محركات وأبواب وكبائن ووحدات التحكم
                            المتطورة ونظم األمان عالية الجودة.
                        </li>
                        <li>
                            نسعى دائما نحو التفوق والتميز بين جميع شركات المصاعد وذلك اعتمادا على
                            الجودة – التكلفة والزمن ، لذلك نحن متحمسون لما نقوم به وهو ارضاء عمالئنا
                            وهذا هو هدفنا األول وليس الربح فقط، إضافة إلى تعظيم صناعة المصاعد
                            وخدمات ما بعد البيع كالضمان المقدم بعد تشغيل المصعد.
                        </li>
                        <li>
                            مؤسسة المصاعد الدولية لديها العديد من أنظمة المصاعد التي قادتها الى التميز
                            والموثوقية وتلبية رغبات جميع العمالء بدءاً من مصاعد األفراد ومصاعد
                            الهيدروليك ومصاعد البضائع ومصاعد الطعام ومصاعد المستشفيات ومصاعد
                            البانوراما إضافة الى المصاعد الداخلية التي ال تحتاج إلى حفر بئر وكراسي الدرج
                            الكهربائية.
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/international-elevators.com/httpdocs/resources/views/frontend/pages/about.blade.php ENDPATH**/ ?>