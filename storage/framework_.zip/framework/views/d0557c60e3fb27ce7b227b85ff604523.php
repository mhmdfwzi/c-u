

<div class="container-fluid page-header my-5 py-5" data-parallax="scroll">
    <div class="container py-5">
        <div class="row g-5">


       
            <div class="col-sm-6 col-lg-3 wow fadeIn" data-wow-delay="0.1s" style="text-align: center; ">
            <i class="fa-solid fa-handshake-simple" style="color: #FFD43B; font-size:3rem; padding-bottom:15px"></i>
          
            <h1 class="display-4 text-white" data-toggle="counter-up"  >
                   3000
                </h1>
                <span class="text-primary" style="font-size:1.8rem; "><b>عدد العملاء</b></span>
            </div>
            <div class="col-sm-6 col-lg-3 wow fadeIn" data-wow-delay="0.3s" style="text-align: center;">

            <i class="fa-solid fa-arrow-trend-up"style="color: #FFD43B; font-size:3rem; padding-bottom:15px"></i>
                <h1 class="display-4 text-white" data-toggle="counter-up">
                    +17
                </h1>
                <span class="text-primary" style="font-size:1.8rem;"><b>سنوات الخبره</b></span>
            </div>
            <div class="col-sm-6 col-lg-3 wow fadeIn" data-wow-delay="0.5s" style="text-align: center;">
            <i class="fa-solid fa-trophy " style="color: #FFD43B; font-size:3rem; padding-bottom:15px"></i>
                <h1 class="display-4 text-white" data-toggle="counter-up">
                    +500
                </h1>
                <span class="text-primary" style="font-size:1.8rem;"><b>المشاريع الناجحة</b></span>
            </div>
            <div class="col-sm-6 col-lg-3 wow fadeIn" data-wow-delay="0.7s" style="text-align: center;" >


            <i class="fa-solid fa-users-gear " style="color: #FFD43B; padding-bottom:15px; font-size:3rem; "></i>
                <h1 class="display-4 text-white" data-toggle="counter-up">
                   +20
                </h1>
                <span class="text-primary" style="font-size:1.8rem;"><b>فريق العمل</b></span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/vhosts/international-elevators.com/httpdocs/resources/views/frontend/pages/HomeParts/numbersSection.blade.php ENDPATH**/ ?>